<?php
require_once ("php/CreateDb.php");
require_once ("php/component.php");
?>
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title></title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="./styles.css">
     <style>
         a{
          color: white;
          text-decoration: none;
        }
          .adminInput{
              margin:auto;
          }
          input {
            width: 250px;
              padding:7px;
              margin:10px;
              cursor: pointer;
          }
          textarea {
              width: 250px;
              height: 200px ;
              padding:7px;
              margin:10px;
          }
      </style>
 </head>
 <body >
     <?php
     require_once ('php/header.php');
     ?>
   <div class="container">
    <div class="row py-3">
      <div class="col p-4">
        <h5 class="py-2 text-center">About us </h5>
      </div>  
       <p class="text-left p-3"> We have built a modern manufacturing unit, which is located 200 Kms away from Mangalore at Kumta in Karnataka. Spread over an area of 35,000 sq. ft., our unit enables us to meet the bulk requirements of our industrial clients. It is also equipped with latest technology machinery that helps us to offer quantitative range of Industrial Safety Hand Gloves, and House Hold Hand Gloves as per clients' specifications. ·         Manufactured from High quality Natural latex. ·         In-process control covering all aspects of manufacturing ensures a consistent high quality. ·         Manufactured and packed under clean and hygienic environment ensuring low Bio-Burden on the gloves. ·         Micro rough surface for that extra grip. ·         Beaded cuff for secure fit. ·         The latex formulation provides excellent elongation to enhance the wearing comfort Swarna Latex, with its past experience has upgraded its glove manufacturing facility and technology well supported by trained and qualified work force. Swarna Latex has introduced a wide range of products for medical and pharmaceutical industries. Swarna Latex introduces the ‘Single Window Shopping’ concept for gloves with diversity in its products. Swarna Latex, well engaged in providing a comprehensive array of Personal Protective Equipment such as Industrial Safety Hand Gloves, House Hold Hand gloves etc Swarna Latex, with its past experience has upgraded its glove manufacturing facility and technology well supported by trained and qualified work force. Swarna Latex has introduced a wide range of products for medical and pharmaceutical industries. Swarna Latex introduces the ‘Single Window Shopping’ concept for gloves with diversity in its products. Swarna Latex, well engaged in providing a comprehensive array of Personal Protective Equipment such as Industrial Safety Hand Gloves, House Hold Hand gloves etc
          An Overview With the overwhelming support of our highly dedicated team as well as our sophisticated facilities, we, Swarna Latex are offering a wide range of Personal Protective Equipment to our clients. Started in the year 2000, we are reckoned as a reputed manufacturer, exporters, and House Hold Hand gloves developed by using latex material. Our range is widely used in the chemical industry, pharmaceutical industry, cement industry, construction industry, and fertilizer industry as well as for housekeeping services. We have established a sound infrastructure that has played an important role in our company’s growth. We are also backed up by a diligent team of experts such as engineers, technicians, quality auditors, and sales & marketing   executives. Moreover, under the leadership and guidance of our mentor, Mr. Manjunath Bhat. We have achieved a remarkable position in the international markets. Our Vision & Mission Our vision is to protect people, products as well as the environment by offering a wide range of occupational, safety, health, and environmental protection products in India. Our mission is to provide customers with high quality products and value-added services at acceptable prices   Services In order to fulfill our commitment to provide better protection, we have invested in the necessary resources and also maintain close communication with our clients to meet all their requirements. We assist our clients in choosing the right product and also provide necessary training sessions for better use of the products. We have employed top-trained specialists who are available for service, whenever and wherever required by customers. Application Areas We offer a wide range of chemical, construction and household gloves, which are widely used for several industrial applications   Hand and Skin protection Quality Assurance As a quality conscious company, Swarna Latex always endeavors to fabricate its range of Industrial Safety Hand Gloves, House Hold hand Gloves etc. with utmost perfection. Owing to our commitment towards maintaining quality centric approach, Our team of quality control monitors the entire production process carefully. The raw material like latex and other chemicals are subject to various tests before being approved for production. They also ensure that our entire array of Personal Protective Equipment conforms to the safety standards. Moreover, our entire range of Personal Protective Equipment is checked on the following parameters: ·         Design ·         Durability ·         Performance ·         Reliability ·         Finish.   We SWARNA LATEX offer a superior quality of industrial rubber hand Gloves to our customers at competitive price. These are manufactured by using advanced technology at our factory located in west coast of Karnataka State. We also ensure that our product range is designed in accordance with Industrial Standards. We also fulfill the bulk demand of specific colored hand gloves to our customers within given time frame.   With the great support of our highly dedicated team as well as our sophisticated facilities, we, are offering a wide range of Personal Protective Equipment to our clients. Started in the year 2000, we are recognized as a reputed manufacturer, exporters of House Hold and Industrial Hand gloves produced by using natural latex.
        </p>
    </div>
   </div>
 </body>
</html>