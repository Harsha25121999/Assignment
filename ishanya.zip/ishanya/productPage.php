
<?php
  require("adminpanel/Connection.php");
require_once ("php/CreateDb.php");
require_once ("php/component.php");
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ALL & ~E_NOTICE);
error_reporting(0);
session_start();
session_regenerate_id(true);    
if(!isset($_SESSION['clientloginid'])){
  header("location: home.php");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles.css">
    <title>Cart</title>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
<style>

.carousel-inner img {
    width: 100%;
    height: 100%;
    
}
#custCarousel .carousel-indicators {
    position: static;
    margin-top: 20px;
    max-height:100px;
}
#custCarousel .carousel-indicators>li {
    width: 100px
}
#custCarousel .carousel-indicators li img {
    display: block;
    opacity: 0.5;
    box-shadow: rgba(255, 255, 255, 0.2) 0px 0px 0px .5px inset, rgba(0, 0, 0, 0.9) 0px 0px 0px 1px;
}

#custCarousel .carousel-indicators li.active img {
    opacity: 1;
}

#custCarousel .carousel-indicators li:hover img {
    opacity: 0.75;
}

.carousel-item img {
    max-width:400px
}
.carousel-control-prev {
color: black;
}
#text-part {
  text-align: left;
}
.img-fluid {
  width:100px;
  height:70px
}
@media screen and (min-width: 780px) {
  #text-part {
  text-align: center;
}
}

</style>

 </head>
 <body >
 <?php
    require_once ('php/header.php');
?>
<section>

 <?php
if(isset($_POST['View']))
{
    $query="SELECT * FROM `upload` WHERE id='$_POST[product_id]'";
    $result=mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($result);
   echo '<div class="container-fluid mt-5">';
      echo '<div class="row" style="max-height:700px">';
       echo  '<div class="col-md-6">';
          echo '<div class="container">';
            echo '<div class="row">';
                echo '<div class="col-md-12">';
                    echo '<div id="custCarousel" class="carousel slide" data-ride="carousel" style="text-align:center">';
                //slides
                        echo '<div class="carousel-inner">';
                            echo '<div class="carousel-item active"> <img style="max-width:500px;max-height: 500px;" src="adminpanel/images/'.$row['img1'].'" alt="Product image" > </div>';
                            echo '<div class="carousel-item"> <img src="adminpanel/images/'.$row['img1'].'" alt="Product image"> </div>';
                            echo '<div class="carousel-item"> <img src="adminpanel/images/'.$row['img2'].'"  alt="Product image"> </div>';
                            echo '<div class="carousel-item"> <img src="adminpanel/images/'.$row['img3'].'" alt="Product image"> </div>';
                            echo '<div class="carousel-item"> <img src="adminpanel/images/'.$row['img4'].'" alt="Product image"> </div>';                           
                            echo '</div> <a class="carousel-control-prev" href="#custCarousel" data-slide="prev"> <span class="carousel-control-prev-icon"></span> </a> <a class="carousel-control-next" href="#custCarousel" data-slide="next"> <span class="carousel-control-next-icon"></span> </a>';
                            echo '<ul class="carousel-indicators list-inline" style="height: 70px;">';
                            echo '<li class="list-inline-item active"><a id="carousel-selector-0" class="selected" data-slide-to="0" data-target="#custCarousel"> <img src="adminpanel/images/'.$row['img1'].'" class="img-fluid"> </a> </li>';
                            echo '<li class="list-inline-item"> <a id="carousel-selector-1" data-slide-to="1" data-target="#custCarousel"> <img src="adminpanel/images/'.$row['img2'].'" class="img-fluid"> </a> </li>';
                            echo '<li class="list-inline-item"> <a id="carousel-selector-2" data-slide-to="2" data-target="#custCarousel"> <img src="adminpanel/images/'.$row['img3'].'" class="img-fluid"> </a> </li>';
                            echo '<li class="list-inline-item"> <a id="carousel-selector-3" data-slide-to="3" data-target="#custCarousel"> <img src="adminpanel/images/'.$row['img4'].'" class="img-fluid"> </a> </li>';
                        echo '</ul>';
                   echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';

        echo '</div>';
        echo '<hr>';
        echo '<div class="col-md-6 col-12 text-left " id="text-part" >';

          echo '<h2 class="col-12 col-md-8 " style="padding-bottom: 30px;">'.$row['name'].'</h2>';
          echo '<hr>';
          echo '<div class="col text-center">';
       
        /*--  echo '<p>'.$row['dprice'].'</p>';*/
      
         echo '<form class="col-12 col-md-8 " action="manage_cart.php" method = "POST" style="font-size: 20px;line-height: 1.2; margin-bottom: 0.4em;">';
                   
                    echo '<input type="hidden" name = "img" value='.$row['img1'].'>';
                    echo '<input type="hidden" name ="pname" value='.$row['name'].'>';
                    echo '<input type="hidden" name ="pdesc" value='.$row['desc1'].'>';
         echo '<div class="col-12 p-3" style="list-style: none;">';
          echo '<button type="submit" class="addtocart" name ="Add_To_Cart_P">Add to Favourites</button>';
          echo '</div>';
          echo '</form>';
           echo '<hr>';
         echo '<p class="col-12 col-md-8 text-center" style="padding-bottom: 30px">'.$row['desc1'].'</p>';
        echo '</div>'; 
       echo '</div>';
      echo '</div>';
   echo '</div>';
}
?>
    </section>
</body>
</html>

