<?php
session_start();

?>
<html>
    <head>
      <title></title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="style.css">
      <title>Swarna Latex</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </head>
 <body>
<header id="header">
<nav class="navbar navbar-expand-md  navbar-light px-5 py-4">
    <a class="navbar-brand" href="./index.php">
        <img src="./swernalogo.jpg"  width="150" height="70" class="d-inline-block align-center" alt="logo">
    </a>
    <button class="navbar-toggler" style="border: none;" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ml-auto text-center">       
        
        <li class="nav-item">    
            <div class="navbar-nav">
                <a href="cart.php" class="nav-item nav-link">
                    <h6 class="px-3 cart">Favourite
                        <?php
                        if (isset($_SESSION['cart'])){
                            $count = count($_SESSION['cart']);
                            echo "<span id=\"cart_count\" class=\"text-warning bg-light\">$count</span>";
                        }else{
                            echo "<span id=\"cart_count\" class=\"text-warning bg-light\">0</span>";
                        }
                        ?>
                    </h6>
                   
                </a>   
                <h2>
                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                <button  class="addtocart" type="submit" name="Logout">LOG OUT</button>
             </form>  
                      </h2>
            </div>    
          </li>     
      </ul>
    </div>
  </nav>
 </header>
 <?php 
if(isset($_POST['Logout']))
{
  session_destroy();
  header("location: home.php");
}
?>
 </body>

</html>





