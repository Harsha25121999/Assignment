<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping Cart</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />

    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="styles.css">

</head>
<body>
<?php

function component($productid, $productname, $productprice,$productimg,$dprice){
    $element = "
    <div class=\"col-md-3 col-sm-6 my-3 my-md-0\">
                <!-- Card-->
                <div class=\"card rounded shadow-sm border-0
                +3 33t+++++ext-center\">
                  <div class=\"card-body p-4\"><img src=\"./adminpanel/images/$productimg\" alt=\"\" class=\"img-fluid d-block mx-auto mb-3\">
                     <h5> <a href=\"#\" class=\"text-dark\">$productname</a></h5>
                  
                     <form action=\"manage_cart.php\" method=\"post\">
                     <input type='hidden' name = 'price' value='$productprice'>
                     <input type='hidden' name = 'img' value='$productimg'>
                     <input type='hidden' name ='pname' value='$productname'>
                     
                     </form>
                     <form action=\"./productPage.php\" method=\"POST\">
                     <input type='hidden' name='product_id' value='$productid'>             
                     <button class=\"addtocart\" name=\"View\">View</button>
                     </form>
                     <input type='hidden' name ='quantity' value ='1'>
                     <input type='hidden' name='product_id' value='$productid'>             
                  </div>
                </div>
            </div>
    ";
    echo $element;
}

function cartElement($productimg, $productname, $productprice, $productid,$productdisc,$quantity){
 $po=1;
    echo '<div class="items">';
    echo '<div class="product">';
      echo  '<div class="row">';
            echo '<div class="col-md-3">';
               echo '<img class="img-fluid mx-auto d-block image" src="./adminpanel/images/'.$productimg.'">';
            echo '</div>';
            echo '<div class="col-md-8">';
             echo '<div class="info">';
                   echo  '<div class="row">';
                      echo '<div class="col-md-5 product-name">';
                          echo '<div class="product-name">';
                                echo '<a href="#">'.$productname.'</a>';
                           echo  '</div>';
                        echo '</div>';
                        echo '<div class="col-md-4 quantity">';        
                        echo '<form action="cart.php" method = "POST">';                                           
                         echo '<input id="quantity" name ="mod_quant" onchange="this.form.submit();" type="number" value ="'.$quantity.'" min ="1" max="1000" class="form-control quantity-input iquantity">';
                         echo '<input type="hidden" name="product_id" value ="'.$productid.'">';            
                         echo '</form>';  
                         echo '<input type="hidden"  class="iprice" value="'.$productprice.'">';
                         echo '<input type="hidden" class="idiscount" value="'.$productdisc.'">';
                        echo '</div>';
                        echo '<div class="col-md-3 ">';
                            echo '<p class="itotal">'.$productprice.'</p>';
                            echo '<form action="cart.php?action=remove&id='.$productid.'" method="post" class="cart-items">';
                            echo '<button class="addtocart" name ="remove" >Delete</button>';
                            echo '</form>';
                       echo  '</div>';                    
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
 echo '<hr>';
echo '</div>';
}
?>
</body>
</html>
















