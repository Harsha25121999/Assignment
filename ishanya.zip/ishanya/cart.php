<?php
require_once ("php/CreateDb.php");
require_once ("php/component.php");
$db = new CreateDb("ishanya", "upload");
if (isset($_POST['remove'])){
  if ($_GET['action'] == 'remove'){
      foreach ($_SESSION['cart'] as $key => $value){
          if($value["product_id"] == $_GET['id']){
              unset($_SESSION['cart'][$key]);
              echo "<script>alert('Product has been Removed...!')</script>";
              echo "<script>window.location = 'cart.php'</script>";
          }
      }
  }
}
if(isset($_POST['mod_quant']))
{
    foreach($_SESSION['cart']as $key =>$value)
    {
        if($value['product_id']==$_POST['product_id'])
        {
            $_SESSION['cart'][$key]['Quantity']=$_POST['mod_quant'];
            print_r($_SESSION['cart']);
            
        }
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cart</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">
<?php
    require_once ('php/header.php');
?>
<section class="shopping-cart dark">
        <div class="container">
        <div class='items'>
             <h2>Favourite Movies List</h2>             
         
           <div class="content">
                <div class="row">
                    <div class="col-md-12 col-lg-8">
                    <?php 
              if(isset($_SESSION['cart']))
              {
                foreach($_SESSION['cart'] as $key => $value)
                {
                  $sr=$key+1;
                  echo"
                   
                  <div class='product'>
                  <div class='row'>
                  <div class='col-md-3'>
                  <img class='img-fluid mx-auto d-block imgage' src='./adminpanel/images/$value[Image]'>
                  
                  </div>
                  <div class='col-md-8'>
                  <div class='info'>
                  <div class='row'>
                  <div class='col-md-5 product-name'>
                  <div class='product-name'>
                  <a href ='#'>$value[Item_Name]</a>
                  </div>
                  </div>
                        <form action='manage_cart.php' method='POST'>
                          <button name='Remove_Item' class='btn btn-sm btn-outline-danger'><i class='fas fa-trash'd></i></button>
                          <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
                        </form>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                 </div>
                  <hr>                  
                  ";
                }
              }
            ?></div>
                 
            </div>
        </div>
        
    </div>
</div>

</section>

    <?php
if(isset($_POST['check']))  
  {
    $content1 = "<script>document.write(itotal[0].innerText)</script>";
    $content2 = "<script>document.write(dtotal.innerText)</script>";
    print_r($content2);
    }
    ?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
