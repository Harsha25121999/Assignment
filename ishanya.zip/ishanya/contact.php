<?php
require_once ("php/CreateDb.php");
require_once ("php/component.php");
?>
<html>
    <head>
      <title></title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </head>
 <body>
     <?php
     require_once('./php/header.php');
     ?>
  <div class="container-fluid pt-5">
      <div class="row">
         
          <div class="col-6 col-sm-4 p-3 text-center">
              <h5>Contact</h5>
              <p>082775 98910<br>083862 95196</p>
              <button class="addtocart"> Call Now </button>
           </div>
           <div class="col-6 col-sm-4 p-3 text-center">
            <h5> Address</h5>
            <p>Suvarnagadde<br>Holegadde<br>Karnataka 581327<br>India<br></p>
            <button class="addtocart" ><a style="color:white" href="https://goo.gl/maps/2hoAcwCBiNUEQeEa7"> Get Dirction</a></button>
           </div>
           <div class="col-12 col-sm-4  p-3 text-center">
           <h5> Opening Hours</h5>
            <p>Mon:	8:00 am – 6:00 pm <br>Tue: 8:00 am – 6:00 pm<br>Wed: 8:00 am – 6:00 pm<br>Thu: 8:00 am – 6:00 pm<br>Fri: 8:00 am – 6:00 pm<br>Sat: 8:00 am – 6:00 pm<br>Sat: 8:00 am – 6:00 pm<br>Sun: 8:00 am – 1:00 pm<p>
            <button class="addtocart"> Get Dirction</button>   
            <div class="col-12 col-sm-6" style = "text-align:center;margin:auto">
           <h4>See on map</h4><br>
         <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3865.220010831451!2d74.41637721480109!3d14.356675689958129!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbc25701e67b7f5%3A0x169074049af99178!2sSwarna%20Latex!5e0!3m2!1sen!2sin!4v1635999699794!5m2!1sen!2sin" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe></p>
               </div>         
           </div>
          
      </div>
   </div>          
 </body>
</html>
