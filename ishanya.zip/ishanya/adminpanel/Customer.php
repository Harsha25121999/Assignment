<?php
  require("Connection.php");
session_start();
session_regenerate_id(true);
if(!isset($_SESSION['AdminLoginId'])){
  header("location: Admin Login.php");
}
?>
<html>
    <head>
      <title>Ishanya CoconutProcessing</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </head>
 <body>         
 <?php
    require_once ('adminheader.php');
?>
  <div class="container-fluid">
      <h3 class="text-center">Customer Details</h3>
      <hr>

      <?php 
            $query="SELECT * FROM `order_manager`";
            $user_result=mysqli_query($con,$query);
            while($user_fetch=mysqli_fetch_assoc($user_result))
            {
        echo "
        <div class='row mx-4'>
        <div class='card p-4'>   
          <span>$user_fetch[Full_Name]</span>
              <hr>
             <span>$user_fetch[email]</span>
             <span>$user_fetch[Phone_No]</span>
             <span>$user_fetch[Address1]</span>
             <span>$user_fetch[Address2]</span>
             <span>$user_fetch[City]</span>
             <span>$user_fetch[State]</span>
             <span>$user_fetch[PinCode]</span>           
          </div>";
            }
            ?>
          
      </div>
  </div>
  <?php 
  if(isset($_POST['Logout']))
  {
    session_destroy();
    header("location: Admin Login.php");
  }
?>
        </body>
        </html>