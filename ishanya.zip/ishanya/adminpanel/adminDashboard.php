<?php
session_start();
session_regenerate_id(true);
if(!isset($_SESSION['AdminLoginId'])){
  header("location: Admin Login.php");
}
  $db = mysqli_connect("localhost", "root", "", "ishanya");
$sql = "SELECT * FROM upload";
$result= mysqli_query($db,$sql);
?>
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Admin Dashboard</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="../styles.css">
      <style>
        a{
          color: white;
          text-decoration: none;
        }
          .adminInput{
              margin:auto;
          }
          input {
            width: 250px;
              padding:7px;
              margin:10px;
              cursor: pointer;
          } 
          textarea {
              width: 250px;
              height: 200px;
              padding:7px;
              margin:10px;
          }
      </style>
 </head>
 <body >

 <?php
    require_once ('adminheader.php');
 ?>        
      <div class="container-fluid" style="padding:50px">
      <div class="row pb-5 mb-4">
  <?php 
 if(mysqli_num_rows($result)>0)
 while($row = mysqli_fetch_assoc($result))
 {
   echo '<div class="col-sm-6 col-md-6 col-lg-4 mb-5">';
     echo '<div class="card rounded shadow-sm border-0 text-center">';
       echo '<div class="card-body p-4"><img src="./images/'.$row['img1'].'" alt="" class="img-fluid d-block mx-auto mb-3">';
        echo '<h5> <a href="#" class="text-dark">'.$row['name'].'</a></h5>';
          echo '<p>'.$row['price'].'</p>';
           echo '<form action = "editProduct.php" method="POST">';
            echo '<input type="hidden" name ="edit_id" value ="'.$row['id'].'">';
             echo '<button class="addtocart" name="edit_btn">Edit</button>';     
             echo '</form>';
             echo '<form action = "" method="POST" >';
             echo '<input type="hidden" name ="edit_id" value ="'.$row['id'].'">';
             echo '<button class="addtocart" name ="dlt_btn">delete</button>';     
            echo '</form>';
         echo '</div>';
       echo '</div>';
    echo '</div>';    
 }
 ?>    
    </div>
  </div>
</div>
<?php
if(isset($_POST['dlt_btn']))
{
  $id = $_POST['edit_id'];
  $sql = "DELETE FROM upload WHERE id='$id'";
  if(mysqli_query($db,$sql))
{
  echo '<script>alert("deleted")</script>';
  header('Refresh: 1; url=adminDashboard.php');
}
else
{
  echo '<script>alert("Not deleted")</script>';
}
}
?>
<?php 
  if(isset($_POST['Logout']))
  {
    session_destroy();
    header("location: Admin Login.php");
  }
?>
 </body>
</html>
