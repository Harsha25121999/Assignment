<?php 

$con=mysqli_connect("localhost","root","","ishanya");

if(mysqli_connect_error()){
  echo"Cannot connect to database";
  exit();
}

?>