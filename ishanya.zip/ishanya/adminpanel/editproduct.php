<?php
session_start();
session_regenerate_id(true);
if(!isset($_SESSION['AdminLoginId'])){
  header("location: Admin Login.php");
}
?>
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Ishanya CoconutProcessing</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="../styles.css">
     <style>
         a{
          color: white;
          text-decoration: none;
        }
          .adminInput{
              margin:auto;
          }
          input {
            width: 250px;
              padding:7px;
              margin:10px;
              cursor: pointer;
          }
          textarea {
              width: 250px;
              height: 200px ;
              padding:7px;
              margin:10px;
          }
      </style>
 </head>
 <body >
    <?php
    require_once ('adminheader.php');
?>   
    <div class="row">
        <div class="adminInput">
       
            <h3 class="text-center mt-4">Edit Product</h3>         
            <?php
             $db = mysqli_connect("localhost", "root", "", "ishanya");
             $id='';
       if(isset($_POST['edit_btn']))
       {
         $id = $_POST['edit_id'];
        $sql = "SELECT * FROM upload WHERE id='$id'";
        $result = mysqli_query($db,$sql);
        foreach($result as $row)
        {
         ?>  
            <form class="card mt-5 p-5" method="POST" action="" enctype="multipart/form-data">     
            <input type="hidden" placeholder="Product Name" name = "id" value = <?php echo $row['id']?>>
            <input type="text" placeholder="Product Name" name = "name" value = <?php echo $row['name']?>>
            <input type="text" placeholder="Product Price" name ="price" value = <?php echo $row['price']?>>
            <input type="text" placeholder="Product Discount Price" name ="dprice" value = <?php echo $row['dprice']?>>
            <textarea  placeholder="Description" name ="desc1" value =<?php echo $row['name']?>><?php echo $row['desc1']?></textarea>
            <p>First image is main image</p>
            <input type="file" name ="image1" > <?php echo $row['img1']?>
            <input type="file" name = "image2">  <?php echo $row['img2']?>
            <input type="file" name = "image3"><?php echo $row['img3']?>
            <input type="file" name ="image4"><?php echo $row['img4']?>
            <input type="file" name="image5"><?php echo $row['img5']?>
            <input type="submit" name ="update" placeholder="Update">
        </form>
      </div>
    </div>
</div>
<?php
        }
        }

            ?>
            <?php
            if(isset($_POST['update']))
            {

              $id1 =  mysqli_real_escape_string($db, $_POST['id']);
              $name1 = mysqli_real_escape_string($db, $_POST['name']);
    $price1 = mysqli_real_escape_string($db, $_POST['price']);
  	$discount= mysqli_real_escape_string($db, $_POST['dprice']);
  	$desc1 = mysqli_real_escape_string($db, $_POST['desc1']);


              if(isset($_FILES['image1']['name']))
              {
              $image1 = $_FILES['image1']['name'];
              $target1= "images/".basename($image1);
              move_uploaded_file($_FILES['image1']['tmp_name'], $target1);
              $sql = "UPDATE `upload` SET `img1`='$image1' WHERE id = '$id1'";
              mysqli_query($db,$sql);
              }
              if(isset($_FILES['image2']['name']))
              {
                $image2 = $_FILES['image2']['name'];
                $target2= "images/".basename($image2);
                move_uploaded_file($_FILES['image2']['tmp_name'], $target2);
                $sql = "UPDATE `upload` SET `img2`='$image2' WHERE id = '$id1'";
                mysqli_query($db,$sql);

              }
              if(isset($_FILES['image3']['name']))
              {
              $image3 = $_FILES['image3']['name'];
              $target3= "images/".basename($image3);
                move_uploaded_file($_FILES['image3']['tmp_name'], $target3);
                $sql = "UPDATE `upload` SET `img3`='$image3' WHERE id = '$id1'";
                mysqli_query($db,$sql);
              }
              if(isset($_FILES['image4']['name']))
              {
              $image4 = $_FILES['image4']['name'];
              $target4= "images/".basename($image4);
                move_uploaded_file($_FILES['image4']['tmp_name'], $target4);
                $sql = "UPDATE `upload` SET `img4`='$image4' WHERE id = '$id1'";
                mysqli_query($db,$sql);
              }
              if(isset($_FILES['image5']['name']))
              {
              $image5 = $_FILES['image5']['name'];
              $target5= "images/".basename($image5);
                move_uploaded_file($_FILES['image1']['tmp_name'], $target5);
                $sql = "UPDATE `upload` SET `img5`='$image5' WHERE id = '$id1'";
                mysqli_query($db,$sql);
              }
    $sql = "UPDATE `upload` SET `name`='$name1',`price`='$price1',`dprice`='$discount',`desc1`='$desc1' WHERE id = '$id1'";
    echo $id;
    if(mysqli_query($db, $sql))
    {
      echo '<script>alert("success")</script>';
    }
    else
    {
      echo '<script>alert("error")</script>';

    }

            }
            ?>
            <?php 
  if(isset($_POST['Logout']))
  {
    session_destroy();
    header("location: Admin Login.php");
  }
?>
</body>
</html>