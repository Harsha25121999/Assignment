<?php
  // Create database connection
  session_start();
session_regenerate_id(true);
if(!isset($_SESSION['AdminLoginId'])){
  header("location: Admin Login.php");
}
  $db = mysqli_connect("localhost", "root", "", "ishanya");
  

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image1 = $_FILES['image1']['name'];
    $image2 = $_FILES['image2']['name']; 
    $image3 = $_FILES['image3']['name'];
    $image4 = $_FILES['image4']['name'];
    $image5 = $_FILES['image5']['name'];

  	// Get text
  	$name1 = mysqli_real_escape_string($db, $_POST['name']);
    $price1 = mysqli_real_escape_string($db, $_POST['price']);
  	$discount= mysqli_real_escape_string($db, $_POST['discount']);
  	$desc1 = mysqli_real_escape_string($db, $_POST['desc']);

    // image file directory
  	$target1= "images/".basename($image1);
    $target2 ="images/".basename($image2);
    $target3 = "images/".basename($image3);
    $target4 = "images/".basename($image4);
    $target5 = "images/".basename($image5);

  	$sql = "INSERT INTO upload (name,price,dprice,desc1,img1,img2,img3,img4,img5) VALUES ('$name1', '$price1','$discount','$desc1','$image1','$image2','$image3','$image4','$image5')";
    
echo $name1;
      // execute query
  	if(mysqli_query($db, $sql))
    {
      echo '<script>alert("Uploaded Successfully")</script>';
    }
    else
    {
      echo '<script>alert("Uploaded Successfully")</script>';
    }
  	if (move_uploaded_file($_FILES['image1']['tmp_name'], $target1) && move_uploaded_file($_FILES['image2']['tmp_name'], $target2)&& move_uploaded_file($_FILES['image3']['tmp_name'], $target3)&& move_uploaded_file($_FILES['image4']['tmp_name'], $target4)&& move_uploaded_file($_FILES['image5']['tmp_name'], $target5)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
?>
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Ishanya CoconutProcessing</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="../styles.css">
     <style>
         a{
          color: white;
          text-decoration: none;
        }
          .adminInput{
              margin:auto;
          }
          input {
            width: 250px;
              padding:7px;
              margin:10px;
              cursor: pointer;
          }
          textarea {
              width: 250px;
              height: 200px ;
              padding:7px;
              margin:10px;
          }
      </style>
 </head>
 <body >
    <body >
    <?php
    require_once ('adminheader.php');
?>
         
    <div class="row">
        <div class="adminInput">        
            <h3 class="text-center mt-5">Upload Product</h3>     
            <form  class="card text-center mt-4 p-5" method="POST" action="productUpload.php" enctype="multipart/form-data">     
            <input type="text" name ="name" placeholder="Product Name">
            <input type="text" name = "price" placeholder="Product Price">
            <input type="text" name ="discount" placeholder="Product Discount Price">
            <textarea name = "desc" placeholder="Description"></textarea>
            <p>First image is main image</p>
            <input type="file" name = "image1">
            <input type="file" name = "image2">
            <input type="file" name = "image3">
            <input type="file" name = "image4" >
            <input type="file" name = "image5">
            <input type="submit" name ="upload" placeholder="Upload">
        </form>    
       </div>
    </div>
</div>
</body>
<?php 
if(isset($_POST['Logout']))
{
  session_destroy();
  header("location: Admin Login.php");
}
?>
</html>