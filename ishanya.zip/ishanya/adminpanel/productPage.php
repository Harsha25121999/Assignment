<?php
  require("adminpanel/Connection.php");
?>

<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" integrity="sha512-3P8rXCuGJdNZOnUx/03c1jOTnMn3rP63nBip5gOP2qmUh5YAdVAvFZ1E+QLZZbC1rtMrQb+mah3AfYW11RUrWA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
       <title>Ishanya CoconutProcessing</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="../styles.css">
     <style>
       
.container {
    margin-top: 100px;
    margin-bottom: 100px
}

.carousel-inner img {
    width: 100%;
    height: 100%
}

#custCarousel .carousel-indicators {
    position: static;
    margin-top: 20px
}

#custCarousel .carousel-indicators>li {
    width: 100px
}

#custCarousel .carousel-indicators li img {
    display: block;
    opacity: 0.5
}

#custCarousel .carousel-indicators li.active img {
    opacity: 1
}

#custCarousel .carousel-indicators li:hover img {
    opacity: 0.75
}

.carousel-item img {
    width: 80%
}
      </style>
 </head>
 <body >
<?php
if(isset($_POST['View']))
{
    $query="SELECT * FROM `upload` WHERE id='$_POST['product_id']'";
    $result=mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($result);
    echo '<div class="container">';
     echo '<div class="row">';
       echo  '<div class="col-md-12">';
            echo '<div id="custCarousel" class="carousel slide" data-ride="carousel" align="center">';
                
                echo '<div class="carousel-inner">';
                    echo '<div class="carousel-item active"> <img src="CoconutProcessing.svg" alt="Hills"> </div>';
                    echo '<div class="carousel-item"> <img src="./CoconutProcessing.svg" alt="Hills"> </div>';
                    echo '<div class="carousel-item"> <img src="./CoconutProcessing.svg" alt="Hills"> </div>';
                    echo '<div class="carousel-item"> <img src="./CoconutProcessing.svg" alt="Hills"> </div>';
                echo '</div> <a class="carousel-control-prev" href="#custCarousel" data-slide="prev"> <span class="carousel-control-prev-icon"></span> </a> <a class="carousel-control-next" href="#custCarousel" data-slide="next"> <span class="carousel-control-next-icon"></span> </a>';
                echo '<ol class="carousel-indicators list-inline">';
                   echo '<li class="list-inline-item active"> <a id="carousel-selector-0" class="selected" data-slide-to="0" data-target="#custCarousel"> <img src="../CoconutProcessing.svg" class="img-fluid"> </a> </li>';
                   echo ' <li class="list-inline-item"> <a id="carousel-selector-1" data-slide-to="1" data-target="#custCarousel"> <img src="../CoconutProcessing.svg" class="img-fluid"> </a> </li>';
                    echo '<li class="list-inline-item"> <a id="carousel-selector-2" data-slide-to="2" data-target="#custCarousel"> <img src="../CoconutProcessing.svg" class="img-fluid"> </a> </li>';
                    echo '<li class="list-inline-item"> <a id="carousel-selector-2" data-slide-to="3" data-target="#custCarousel"> <img src="../CoconutProcessing.svg" class="img-fluid"> </a> </li>';
                echo '</ol>';
           echo '</div>';
        echo '</div>';
    echo '</div>';
echo '</div>';
}
?>
