
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <title>Admin Dashboard</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="../styles.css">
      <style>
        a{
          color: white;
          text-decoration: none;
        }
          .adminInput{
              margin:auto;
          }
          input {
            width: 250px;
              padding:7px;
              margin:10px;
              cursor: pointer;
          }
          textarea {
              width: 250px;
              height: 200px;
              padding:7px;
              margin:10px;
          }
      </style>
 </head>
 <body >

 <div class="container-fluid">
        <div class="row text-center mb-1" style="background-color: white;">
          <div class="col-6 mt-3" >  <h2>ADMIN PANEL </h2>  </div>
          <div class="col-6 mt-4 text-right" >
             <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                <button  class="addtocart" type="submit" name="Logout">LOG OUT</button>
             </form>          
         </div>    
     </div>
       <div class="row text-center" style="background-color: white;">
        <div class="col-12 p-5" style="list-style: none;">            
           <button class="addtocart"><a href="./productUpload.php">Upload Product </a></button>
           <button  class="addtocart"><a href="./adminDashboard.php">Edit Product</a></button>
           <button  class="addtocart"><a href="./Admin Panel.php">Admin Panel</a></button>
           <button  class="addtocart"><a href="./Customer.php">Customer</a></button>
        </div>
      </div>    
     </div>    
  </div>        
</body>
</html>
 <?php 