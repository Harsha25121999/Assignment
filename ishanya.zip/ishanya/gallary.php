<html>
    <head>
      <title></title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </head>
 <body>
  <div class="container">
      <div class="row">
          <div class="col-12">
              <img src="#"/>
          </div>
          <div class="col-6 col-sm-4">
              <h5>Contact</h5>
              <p>082775 98910<br>083862 95196</p>
           </div>
           <div class="col-6 col-sm-4">
            <h5> Address</h5>
            <p>Suvarnagadde<br>Holegadde<br>Karnataka 581327<br>India<br></p>
           </div>
           <div class="col-6 col-sm-4">
           <h5> Opening Hours</h5>
            <p>Mon:	8:00 am – 6:00 pm <br>Tue:	8:00 am – 6:00 pm<br>Wed:	8:00 am – 6:00 pm<br>Thu:	8:00 am – 6:00 pm<br>Fri:	8:00 am – 6:00 pm<br>Sat:	8:00 am – 6:00 pm<br>Sat:	8:00 am – 6:00 pm<br>Sun:	8:00 am – 1:00 pm<p>
           </div>
      </div>
   </div>          
 </body>
</html>
